package MVCController;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Register
 */
public class Register extends HttpServlet {
  private static final long serialVersionUID = 1L;
  private final String url="jdbc:mysql://localhost:3306/project";
  private final String user="root";
  private final String pass="Charan@2004";
    
  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    
  }


  protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    String username=request.getParameter("name");
    String email=request.getParameter("email");
    String password=request.getParameter("password");
    String confirmpassword=request.getParameter("password1");
    PrintWriter pw=response.getWriter();
      if (!password.equals(confirmpassword)) {
              pw.print("Password Validation Failed");
              return;
          }
    
    Connection con=null;
    PreparedStatement ps=null;
    try {
      con=DriverManager.getConnection(url,user,pass);
      //Statement st=con.createStatement();
      ps=con.prepareStatement("Insert Into cust values(?,?,?)");
      ps.setString(1, username);
      ps.setString(2, email);
      ps.setString(3, password);
      
      ps.executeUpdate();
      pw.print("Success");
    }
    catch(Exception e) {
      
    }
    

  }

}