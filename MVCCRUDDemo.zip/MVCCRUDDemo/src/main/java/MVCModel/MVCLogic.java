package MVCModel;
import java.sql.*;
import java.util.*;
public class MVCLogic 
{
	String dburl = "jdbc:mysql://localhost:3306/project";
	String dbun = "root";
	String dbpw = "Charan@2004";
	Connection con =null;
	PreparedStatement ps = null;
	ResultSet rs = null;
	
	public boolean MVCValidate (MVCData md) throws Exception
	{
		con = DriverManager.getConnection(dburl, dbun,dbpw);
		ps = con.prepareStatement("select count(*) from cust where username = ? and password = ?");
		ps.setString(1, md.getUsername());
		ps.setString(2, md.getPassword());
		rs = ps.executeQuery();
		if(rs.next())
		{
			if(rs.getInt(1) == 1)
			{
				return true;
			}
			else
			{	
				return false;
			}
		}
		return false;
	}
	
	
	public List<MVCData> MVCgetALL () throws Exception
	{
		con = DriverManager.getConnection(dburl, dbun,dbpw);
		ps = con.prepareStatement("select * from customer");
		rs = ps.executeQuery();
		List<MVCData> L = new ArrayList<MVCData>();
		while(rs.next())
		{
			MVCData md = new MVCData();
			md.setId(rs.getString(1));
			md.setName(rs.getString(2));
			md.setPrice(rs.getString(3));
			md.setQuantity(rs.getString(4));
			
			L.add(md);
		}
		con.close();
		return L;
		
		
	}
	public boolean insertData (MVCData md) throws Exception
	{
		try {
		con = DriverManager.getConnection(dburl, dbun,dbpw);
		Statement st = con.createStatement();
		 st.executeUpdate("insert into customer values ('"+md.getId()+"','"+md.getName()+"','"+md.getPrice()+"','"+md.getQuantity()+"')");
		return true;
		}
		catch(Exception e)
		{
			return false;
		}
	}
	public boolean updateData (MVCData md) throws Exception
	{
		try {
		con = DriverManager.getConnection(dburl, dbun,dbpw);
		ps = con.prepareStatement("update customer set quantity=? where id=?");
		ps.setString(1, md.getId());
		ps.setString(2,md.getName());
		ps.setString(3, md.getPrice());
		ps.setString(4, md.getQuantity());
		 ps.execute();
		return true;
		}
		catch(Exception e)
		{
			return false;
		}
	}
	public boolean deleteData (MVCData md) throws Exception
	{
		try {
		con = DriverManager.getConnection(dburl, dbun,dbpw);
		ps = con.prepareStatement("delete from customer where id=?");
		ps.setString(1, md.getId());
		 ps.execute();
		return true;
		}
		catch(Exception e)
		{
			return false;
		}
	}
	public List<MVCData> searchData (String S) throws Exception
	{
		con = DriverManager.getConnection(dburl, dbun,dbpw);
		ps = con.prepareStatement("select * from customer where id=?");
		ps.setString(1, S);
		rs = ps.executeQuery();
		List<MVCData> L = new ArrayList<MVCData>();
		while(rs.next())
		{
			MVCData mdout = new MVCData();
			mdout.setId(rs.getString(1));
			mdout.setName(rs.getString(2));
			mdout.setPrice(rs.getString(3));
			mdout.setQuantity(rs.getString(4));
			L.add(mdout);
		}
		con.close();
		return L;
		
		
	}
}
